<div id="comments" class="comments-area">
	<div id="comments">
		<ol class="commentlist">
			<?php wp_list_comments(); ?>
		</ol>
	</div>

	<div class="clear"></div>
</div>

