<?php


$fields['_bs_review_box_padding_top']    = array(
	'css-echo-default' => FALSE,
	'css'              => array(
		array(
			'selector' => array(
				'.betterstudio-review'
			),
			'prop'     => array( 'padding-top' => '%%value%%px' ),
		)
	),
);
$fields['_bs_review_box_padding_bottom'] = array(
	'css-echo-default' => FALSE,
	'css'              => array(
		array(
			'selector' => array(
				'.betterstudio-review'
			),
			'prop'     => array( 'padding-bottom' => '%%value%%px' ),
		)
	),
);
$fields['_bs_review_box_padding_left']   = array(
	'css-echo-default' => FALSE,
	'css'              => array(
		array(
			'selector' => array(
				'.betterstudio-review'
			),
			'prop'     => array( 'padding-left' => '%%value%%px' ),
		)
	),
);
$fields['_bs_review_box_padding_right']  = array(
	'css-echo-default' => FALSE,
	'css'              => array(
		array(
			'selector' => array(
				'.betterstudio-review'
			),
			'prop'     => array( 'padding-right' => '%%value%%px' ),
		)
	),
);

